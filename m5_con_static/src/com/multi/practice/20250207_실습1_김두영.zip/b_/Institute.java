package com.multi.practice.b_;

public class Institute {
    public static void main(String[] args) {
        Enroll sub1 = new Enroll("자바", "14:30", "밤식이");
        Enroll sub2 = new Enroll("JSP", "9:30", "밤톨이");

        System.out.println(sub1);
        System.out.println(sub2);
    }
}
