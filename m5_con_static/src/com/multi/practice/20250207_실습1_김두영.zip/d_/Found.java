package com.multi.practice.d_;

public class Found {
    public static void main(String[] args) {
        Employee work1 = new Employee("밤순이", 25, 'f');
        Employee work2 = new Employee("밤식이", 24, 'm');
        Employee work3 = new Employee("밤실이", 26, 'f');

        System.out.println(Employee.getCount());
        System.out.println(work1);
        System.out.println(work2);
        System.out.println(work3);
        System.out.println(Employee.getAvgAge());
    }

}
