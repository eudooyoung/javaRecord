package com.multi.practice.c_;

public class BbsUse {
    public static void main(String[] args) {
        Bbs p1 = new Bbs("java", "fun java", "park");
        Bbs p2 = new Bbs("jsp", "fun jsp", "hong");
        Bbs p3 = new Bbs("spring", "fun spring", "kim");

        System.out.println("게시판");
        System.out.println("-------");
        System.out.printf("%-3s\t%-4s\t%-8s\t%-5s\t\n", "no", "title", "content", "writer");
        System.out.printf("1\t%-5s\t%-8s\t%-5s\t\n", p1.getTitle(), p1.getContent(), p1.getWriter());
        System.out.printf("2\t%-5s\t%-8s\t%-5s\t\n", p2.getTitle(), p2.getContent(), p2.getWriter());
        System.out.printf("3\t%-5s\t%-8s\t%-5s\t\n", p3.getTitle(), p3.getContent(), p3.getWriter());


    }
}
