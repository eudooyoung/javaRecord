package com.uni.stream.homework;

public class Run {
    public static void main(String[] args) {
        new VoteMenu().mainMenu();
    }
}
