package com.multi.homework;

import java.util.ArrayList;
import java.util.List;

public class VoteController {

    private List<Candidate> candidatelist = new ArrayList<>();

    public boolean registerCandidate(String name) {
        boolean isRegistered = false;

        if (candidatelist.isEmpty()) {
            Candidate candidate = new Candidate(name); // Candidate 객체 생성
            candidatelist.add(candidate);
            isRegistered = true;
        } else {
            if (!hasSame(name)) {
                Candidate candidate = new Candidate(name); // Candidate 객체 생성
                candidatelist.add(candidate);
                isRegistered = true;
            }
        }
        return isRegistered;
    }

    private boolean hasSame(String name) {
        boolean hasSame = false;
        for (Candidate candidate : candidatelist) {
            if (candidate.getName().equalsIgnoreCase(name)) {
                hasSame = true;
                break;
            }
        }
        return hasSame;
    }

    public List<Candidate> getCandidateList() {
        return this.candidatelist;
    }

    public boolean removeCandidate(String name) {
        boolean isRemoved = false;
        for (int i = 0; i < candidatelist.size(); i++) {
            if (candidatelist.get(i).getName().equalsIgnoreCase(name)) {
                candidatelist.remove(i);
                isRemoved = true;
                break;
            }
        }
        return isRemoved;
    }

    public boolean voteCandidate(String name) {
        boolean isVoted = false;
        for (Candidate candidate : candidatelist) {
            if (candidate.getName().equalsIgnoreCase(name)) {
                candidate.addVote();
                isVoted = true;
                break;
            }
        }
        return isVoted;
    }

    public void getWinner() {
        if (!isValid()) {
            System.out.println("아무도 투표를 하지 않은 것 같군요.");
        } else {
            StringBuffer winner = new StringBuffer();
            int maxVote = 0;

            for (int i = 0; i < candidatelist.size(); i++) {
                System.out.println(candidatelist.get(i));
                if (candidatelist.get(i).getVotes() > maxVote) {
                    maxVote = candidatelist.get(i).getVotes();
                    winner.setLength(0);
                    winner.append(candidatelist.get(i).getName());
                } else if (candidatelist.get(i).getVotes() == maxVote) {
                    winner.append(", ").append(candidatelist.get(i).getName());
                }
            }
            System.out.printf("우승자: %s 총 득표수: %d표 \n축하합니다!", winner, maxVote);
        }
    }

    private boolean isValid() {
        boolean isValid = false;
        for (Candidate candidate : candidatelist) {
            if (candidate.getVotes() != 0) {
                isValid = true;
                break;
            }
        }
        return isValid;
    }
}
