package com.multi.homework.vote;

public class Run {
    public static void main(String[] args) {
        new VoteMenu().mainMenu();
    }
}
